# VectorUnforget

[![License: AGPL v3](https://img.shields.io/badge/License-AGPLv3-blue.svg)](https://www.gnu.org/licenses/agpl-3.0)
[![Python Version](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![Tests](https://img.shields.io/badge/tests-100%25%20passing-brightgreen.svg)]()

**VectorUnforget** is a modular, zero-leakage framework designed to implement the **GDPR/CCPA "Right to be Forgotten"** across enterprise vector databases and Retrieval-Augmented Generation (RAG) pipelines.

It ensures complete cascaded erasure of primary and secondary PII, provides cryptographic SHA-256 audit trails, runs adversarial RAG verification queries, and enables mathematical vector unlearning via orthogonal subspace projection.

---

## Key Features

- **Cascading PII Erasure:** Erases seed entities along with multi-hop correlated identifiers (SSN, Tax IDs, IP addresses, IBANs, emails, phone numbers) using dynamic graph resolution.
- **Enterprise DB Adapters:** Native support for **Pinecone**, **Weaviate**, **Qdrant**, **Pgvector**, and **ChromaDB**.
- **Framework Middleware:** Drop-in adapters for **LangChain** (`VectorUnforgetRetriever`) and **LlamaIndex** (`VectorUnforgetNodePostprocessor`).
- **Adversarial Verification:** `ReverseRAGVerifier` executes adversarial RAG queries post-erasure and calculates the *Zero Residual Leakage Score*.
- **Semantic Vector Unlearning:** `SubspaceProjector` eliminates sensitive concepts directly in embedding space via orthogonal subspace projection without requiring index re-training.
- **Auditing & Safety:** Dry-run execution modes and tamper-evident SHA-256 signed audit certificates.

---

## Architecture

```text
[ Primary Entity / Seed ]
           │
           ▼
┌───────────────────────┐
│   PIIEntityGraph      │ ──► Multi-hop transitive entity discovery
└───────────────────────┘
           │
           ▼
┌───────────────────────┐
│ VectorUnforgetEngine  │ ──► Cascading metadata/vector scanner
└───────────────────────┘
     │             │
     ▼             ▼
┌─────────┐   ┌────────────────────────┐
│ Dry Run │   │ Database Adapter       │ (Qdrant, Pgvector, Chroma, Pinecone, Weaviate)
└─────────┘   └────────────────────────┘
                       │
                       ▼
              ┌──────────────────┐
              │ Auditor (SHA256) │ ──► Verifiable compliance record
              └──────────────────┘
                       │
                       ▼
              ┌─────────────────────┐
              │ ReverseRAGVerifier  │ ──► Zero Residual Leakage Score
              └─────────────────────┘
```

---

## Quickstart

### 1. Installation

```bash
git clone https://github.com/Toskurim/vector-unforget.git
cd vector-unforget
pip install -r requirements.txt
```

### 2. Multi-Hop Cascading Erasure

```python
from vector_unforget.graph_resolver import PIIEntityGraph

graph = PIIEntityGraph(decay_factor=0.8)

# Ingest entity relationships from document chunks
graph.link_chunk("chunk_1", {"Mario Rossi", "mario.rossi@company.com"})
graph.link_chunk("chunk_2", {"mario.rossi@company.com", "192.168.1.50"})
graph.link_chunk("chunk_3", {"192.168.1.50", "IT60X0542811101000000123456"})

# Cascade from primary identifier
resolved = graph.resolve_cascading_entities("Mario Rossi", max_depth=3, min_confidence=0.5)
affected_chunks = graph.get_affected_chunks(resolved)

print("Entities to purge:", resolved)
print("Affected chunks:", affected_chunks)
```

### 3. Pinecone / Weaviate Adapter Usage

```python
from vector_unforget.adapters import PineconeAdapter
# from vector_unforget.adapters import WeaviateAdapter

adapter = PineconeAdapter(index=pinecone_index, namespace="production")

# Dry run simulation
dry_run_report = adapter.delete_records(target_ids=["vec-101", "vec-102"], dry_run=True)
print("Simulation result:", dry_run_report)

# Permanent hard deletion
purge_report = adapter.delete_records(target_ids=["vec-101", "vec-102"], dry_run=False)
```

### 4. Reverse RAG Adversarial Verification

```python
from vector_unforget.verifier import ReverseRAGVerifier

verifier = ReverseRAGVerifier(adapter)
report = verifier.verify_erasure(
    target_name="Mario Rossi",
    extracted_pii={"mario.rossi@company.com", "192.168.1.50"},
)

print(f"Compliance status: {report['is_fully_compliant']}")
print(f"Zero Leakage Score: {report['zero_residual_leakage_score']}%")
```

### 5. Semantic Subspace Projection (Vector Unlearning)

```python
from vector_unforget.subspace_projection import SubspaceProjector

projector = SubspaceProjector()

# Nullify sensitive concept direction from target embeddings
unlearned_vector = projector.project_orthogonal(
    target_vector=[0.8, 0.6, 0.0],
    concept_vector=[1.0, 0.0, 0.0],
)
```

---

## Running Tests

Run the full automated test suite:

```bash
python -m pytest
```

---

## License

This project is licensed under the **GNU Affero General Public License v3.0 (AGPLv3)**. See the `LICENSE` file for details.

- **Author:** Toskurim
- **Contact:** toskurim@gmail.com